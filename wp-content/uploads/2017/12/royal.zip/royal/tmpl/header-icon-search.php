<li class="search-box">
	<a href="#"><i class="fa fa-search"></i></a>
	<?php the_widget( 'WP_Widget_Search' ) ?>
</li>